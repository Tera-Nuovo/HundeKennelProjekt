﻿using System;
namespace HundKenneProjekt
{
    public class DogSpecifier
    {
        static public int GetDogSpecifier(int input)
        {

            return input - 1;
        }
    }
}

